#Make directories and move stuff
mkdir $HOME/.exploratory/
mkdir $HOME/.exploratory/"Fear Of The Dark"/
mkdir $HOME/.exploratory/"Fear Of The Dark"/Saves/
mv Assets $HOME/.exploratory/"Fear Of The Dark"/
mv "Fear Of The Dark" $HOME/.exploratory/"Fear Of The Dark"/

#install CEGUI
mkdir CEGUI
cd CEGUI
tar -xf ../cegui-0.8.7.tar.bz2 .
./configure
make -j$(nproc)
make install -j$(nproc)
cd ..
rm -r CEGUI
rm cegui-0.8.7..tar.bz2

#make a link to the desktop
ln $HOME/.exploratory/"Fear Of The Dark"/"Fear Of The Dark" $HOME/Desktop/

#clean up
cd ..
rm -r FOTDInstall
