This folder is for ASSETS only
That includes:
  1. Concept Art (Goes in "Art/Concept")
  2. Music (Goes in the "Music" folder)
  3. Sound Effects (Go in the "Sounds" folder)
  4. Animations (Go in "Art/Animations" folder)
  5. Spritesheets (Go in "Art/Spritesheets" folder)
  6. Mob/Entity Textures (Go in "Art/Entities" folder)
