gksudo ./.linuxinstall.sh
