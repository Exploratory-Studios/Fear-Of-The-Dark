This folder is for SPRITESHEETS only!!!
If you don't know what a spritesheet is, you shouldn't be here!
