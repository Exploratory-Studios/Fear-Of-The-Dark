local QuestFunctions = {} -- Make a global table.

function QuestFunctions.testFunc()
	print("Test")
end

return QuestFunctions
